Sebuah aplikasi keuangan 
